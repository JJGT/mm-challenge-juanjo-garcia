In order to be able to run this project properly:

1. Build the project
2. Run the APITests class