import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;


public class APITests {

    final static String jsonurl="https://www.purgomalum.com/service/json?text=";
    final static String containsurl="https://www.purgomalum.com/service/containsprofanity?text=";

    public static void main(String args[]) {
        noProfanity();
        profanity();
        addProfanityWord();
        profanityFillText();
        profanityErrorFillTextToLong();
        profanityFillChar();
        profanityErrorFillNonValidChar();
        profanityAddWordAndValidChar();
        positiveContainsProfanity();
        negativeContainsProfanity();
        noInputError();
    }

    public static void noProfanity() {
        String input = "this is some test input";
        given()
        .when().get(jsonurl + input)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some test input"));
    }

    public static void profanity() {
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some **** test input"));
    }

    public static void addProfanityWord() {
        String add = "&add=word";
        String input = "this is some word test input";
        given()
        .when().get(jsonurl + input + add)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some **** test input"));
    }

    public static void profanityFillText() {
        String fill_text = "&fill_text=happy";
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input + fill_text)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some happy test input"));
    }

    public static void profanityErrorFillTextToLong() {
        String fill_text = "&fill_text=long text of more than 20 characters";
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input + fill_text)
        .then().statusCode(200)
        .and().assertThat().body("error", equalTo("User Replacement Text Exceeds Limit of 20 Characters."));
    }

    public static void profanityFillChar() {
        String fill_char = "&fill_char=|";
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input + fill_char)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some |||| test input"));
    }

    public static void profanityErrorFillNonValidChar() {
        String fill_char = "&fill_char=+";
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input + fill_char)
        .then().statusCode(200)
        .and().assertThat().body("error", equalTo("Invalid User Replacement Characters"));
    }

    public static void positiveContainsProfanity() {
        String input = "this is some shit test input";
        given()
        .when().get(containsurl + input)
        .then().statusCode(200)
        .and().assertThat().body(containsString("true"));
    }

    public static void negativeContainsProfanity() {
        String input = "this is some test input";
        given()
        .when().get(containsurl + input)
        .then().statusCode(200)
        .and().assertThat().body(containsString("false"));
    }

    public static void profanityAddWordAndValidChar() {
        String add = "&add=test";
        String fill_char = "&fill_char=_";
        String input = "this is some shit test input";
        given()
        .when().get(jsonurl + input + add + fill_char)
        .then().statusCode(200)
        .and().assertThat().body("result", equalTo("this is some ____ ____ input"));
    }

    public static void noInputError() {
        String input = "";
        given()
        .when().get(jsonurl + input)
        .then().statusCode(200)
        .and().assertThat().body("error", equalTo("No Input"));
    }
}
